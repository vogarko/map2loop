import configparser
config = configparser.ConfigParser()
config.read('map2loop.ini')

def get_param(config,block,param):
    value=config[block][param]
    print(param,'=',value)
    return(value)

gcode = get_param(config, 'CODES', 'gcode' )
dcode = get_param(config, 'CODES', 'dcode' )
ddcode = get_param(config, 'CODES', 'ddcode' )
ccode = get_param(config, 'CODES', 'ccode' )
ncode = get_param(config, 'CODES', 'ncode' )
ocode = get_param(config, 'CODES', 'ocode' )
rcode = get_param(config, 'CODES', 'rcode' )
tcode = get_param(config, 'CODES', 'tcode' )
fcode = get_param(config, 'CODES', 'fcode' )
dscode = get_param(config, 'CODES', 'dscode' )
mincode = get_param(config, 'CODES', 'mincode' )
maxcode = get_param(config, 'CODES', 'maxcode' )
sill_label = get_param(config, 'CODES', 'sill_label' )
intrusive_label = get_param(config, 'CODES', 'intrusive_label' )
orientation_decimate = get_param(config, 'DECIMATION', 'orientation_decimate' )
contact_decimate = get_param(config, 'DECIMATION', 'contact_decimate' )
fault_decimate = get_param(config, 'DECIMATION', 'fault_decimate' )
fold_decimate = get_param(config, 'DECIMATION', 'fold_decimate' )
gridx = get_param(config, 'INTERPOLATION', 'gridx' )
gridy = get_param(config, 'INTERPOLATION', 'gridy' )
scheme = get_param(config, 'INTERPOLATION', 'scheme' )
dist_buffer = get_param(config, 'INTERPOLATION', 'dist_buffer' )
pluton_dip = get_param(config, 'ASSUMPTIONS', 'pluton_dip' )
pluton_form = get_param(config, 'ASSUMPTIONS', 'pluton_form' )
fault_dip = get_param(config, 'ASSUMPTIONS', 'fault_dip' )
latmin = get_param(config, 'ROI', 'latmin' )
latmax = get_param(config, 'ROI', 'latmax' )
longmin = get_param(config, 'ROI', 'longmin' )
longmax = get_param(config, 'ROI', 'longmax' )
step_out = get_param(config, 'ROI', 'step_out' )
minx = get_param(config, 'ROI', 'minx' )
maxx = get_param(config, 'ROI', 'maxx' )
miny = get_param(config, 'ROI', 'miny' )
maxy = get_param(config, 'ROI', 'maxy' )
src_crs  = get_param(config, 'CRS', 'src_crs' )
dst_crs  = get_param(config, 'CRS', 'dst_crs' )
mname = get_param(config, 'PATH', 'mname' )
geology_file = get_param(config, 'PATH', 'geology_file' )
fault_file = get_param(config, 'PATH', 'fault_file' )
structure_file = get_param(config, 'PATH', 'structure_file' )
model_base = get_param(config, 'MODEL_EXTENTS', 'model_base' )

test_data_path='../test_data3/'
graph_path=test_data_path+'graph/'
strat_graph_file=test_data_path+'graph/output/'+mname+'_strat.gml'

tmp_path=test_data_path+'tmp/'
data_path=test_data_path+'data/'

fault_file=data_path+'GEOS_GEOLOGY_LINEARSTRUCTURE_500K_GSD.shp'
structure_file=data_path+'hams2_structure.shp'
geology_file=data_path+'hams2_geol.shp'

fault_file_csv=data_path+'GEOS_GEOLOGY_LINEARSTRUCTURE_500K_GSD.csv'
structure_file_csv=data_path+'hams2_structure.csv'
geology_file_csv=data_path+'hams2_geol.csv'


bbox=str(miny)+","+str(minx)+","+str(maxy)+","+str(maxx)
lat_point_list = [miny, miny, maxy, maxy, maxy]
lon_point_list = [minx, maxx, maxx, minx, minx]
bbox_geom = Polygon(zip(lon_point_list, lat_point_list))
polygon = gpd.GeoDataFrame(index=[0], crs=dst_crs, geometry=[bbox_geom]) 

print(bbox)
bbox=(minx,miny,maxx,maxy)

if(not os.path.isdir(graph_path)):
    os.mkdir(graph_path)
if(not os.path.isdir(tmp_path)):
    os.mkdir(tmp_path)
